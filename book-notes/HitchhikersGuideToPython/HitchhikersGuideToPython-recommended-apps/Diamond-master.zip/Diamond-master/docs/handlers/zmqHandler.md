<!--This file was generated from the python source
Please edit the source to make changes
-->
zmqHandler
=====

Output the collected values to a Zer0MQ pub/sub channel

#### Options

Setting | Default | Description | Type
--------|---------|-------------|-----
get_default_config_help |  | get_default_config_help | 
port | 1234 |  | int
server_error_interval | 120 | How frequently to send repeated server errors | int
