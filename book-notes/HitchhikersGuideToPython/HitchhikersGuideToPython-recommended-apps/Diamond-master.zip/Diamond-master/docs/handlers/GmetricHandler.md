<!--This file was generated from the python source
Please edit the source to make changes
-->
GmetricHandler
=====

Emulate a gmetric client for usage with
[Ganglia Monitoring System](http://ganglia.sourceforge.net/)

#### Options

Setting | Default | Description | Type
--------|---------|-------------|-----
get_default_config_help |  | get_default_config_help | 
host | localhost | Hostname | str
port | 8651 | Port | int
protocol | udp | udp or tcp | str
server_error_interval | 120 | How frequently to send repeated server errors | int
