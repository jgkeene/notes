<!--This file was generated from the python source
Please edit the source to make changes
-->
MySQLHandler
=====

Insert the collected values into a mysql table

#### Options

Setting | Default | Description | Type
--------|---------|-------------|-----
