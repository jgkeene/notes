<!--This file was generated from the python source
Please edit the source to make changes
-->
FilesCollector
=====

This class collects data from plain text files

#### Dependencies


#### Options

Setting | Default | Description | Type
--------|---------|-------------|-----
byte_unit | byte | Default numeric output(s) | str
delete | False | Delete files after they are picked up | bool
dir | /tmp/diamond | The directory that the performance files are in | str
enabled | False | Enable collecting these metrics | bool
measure_collector_time | False | Collect the collector run time in ms | bool
metrics_blacklist | None | Regex to match metrics to block. Mutually exclusive with metrics_whitelist | NoneType
metrics_whitelist | None | Regex to match metrics to transmit. Mutually exclusive with metrics_blacklist | NoneType
path | . | Prefix added to all stats collected by this module, a single dot means dont add prefix | str

#### Example Output

```
__EXAMPLESHERE__
```

